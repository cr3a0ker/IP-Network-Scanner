import whois
import socket
import requests
from tabulate import tabulate
from colorama import Fore, Back, Style, init

# Initialisiere die Farben
init(autoreset=True)

# Funktion zum Anzeigen des Banners
def display_banner():
    print(Fore.YELLOW + Style.BRIGHT + """
    
 ██████╗██████╗ ██████╗  █████╗  ██████╗ ██╗  ██╗███████╗██████╗     ██╗██████╗ 
██╔════╝██╔══██╗╚════██╗██╔══██╗██╔═████╗██║ ██╔╝██╔════╝██╔══██╗    ██║██╔══██╗
██║     ██████╔╝ █████╔╝███████║██║██╔██║█████╔╝ █████╗  ██████╔╝    ██║██████╔╝
██║     ██╔══██╗ ╚═══██╗██╔══██║████╔╝██║██╔═██╗ ██╔══╝  ██╔══██╗    ██║██╔═══╝ 
╚██████╗██║  ██║██████╔╝██║  ██║╚██████╔╝██║  ██╗███████╗██║  ██║    ██║██║     
 ╚═════╝╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚═╝╚═╝     
                                                                                
    """)

# Passwortabfrage
def password_prompt():
    correct_password = "cr3a0ker"  # Setze hier dein Passwort
    password = input(Fore.GREEN + "🔒 Gib dein Passwort ein: ")

    if password == correct_password:
        print(Fore.GREEN + "✅ Passwort korrekt!")
        return True
    else:
        print(Fore.RED + "❌ Falsches Passwort!")
        return False

# IP Lookup (Geografische Details)
def ip_lookup(ip):
    url = f"http://ip-api.com/json/{ip}?fields=66846719"  # Holt alle verfügbaren Daten

    try:
        response = requests.get(url, timeout=5)
        data = response.json()

        if data.get("status") == "fail":
            print(Fore.RED + "❌ Ungültige IP oder Domain!")
            return

        ip_info = [
            [" IP-Adresse", data.get("query", "Unbekannt")],
            [" Land", f"{data.get('country', 'Unbekannt')} ({data.get('countryCode', '-')})"],
            [" Stadt", f"{data.get('city', 'Unbekannt')}, {data.get('regionName', 'Unbekannt')}"],
            [" PLZ", data.get("zip", "Unbekannt")],
            [" ISP (Provider)", data.get("isp", "Unbekannt")],
            [" Organisation", data.get("org", "Unbekannt")],
            [" AS-Nummer", data.get("as", "Unbekannt")],
            [" Koordinaten", f"{data.get('lat', 'N/A')}, {data.get('lon', 'N/A')}"],
            [" Zeitzone", data.get("timezone", "Unbekannt")],
            [" Mobilnetz?", "Ja" if data.get("mobile") else "Nein"],
            [" Proxy/VPN?", "Ja" if data.get("proxy") else "Nein"],
            [" Hosting/Rechenzentrum?", "Ja" if data.get("hosting") else "Nein"]
        ]

        print(Fore.GREEN + "\n🔍 IP-Informationen:")
        print(tabulate(ip_info, tablefmt="fancy_grid"))
    except requests.exceptions.RequestException:
        print(Fore.RED + "⚠️ Fehler: Konnte keine Verbindung herstellen!")

# WHOIS Lookup (Daten über Domain oder IP)
def whois_lookup(domain):
    try:
        w = whois.whois(domain)
        whois_info = [
            ["Domain", domain],
            ["Registrar", w.registrar],
            ["Erstellt am", w.creation_date],
            ["Zuletzt aktualisiert", w.updated_date],
            ["Ablaufdatum", w.expiration_date],
            ["Kontakt-E-Mail", w.emails if w.emails else "Nicht verfügbar"],
            ["Name Server", w.name_servers if w.name_servers else "Nicht verfügbar"]
        ]
        print(Fore.GREEN + "\n🔍 WHOIS-Daten:")
        print(tabulate(whois_info, tablefmt="fancy_grid"))
    except Exception as e:
        print(Fore.RED + f"❌ Fehler beim Abrufen der WHOIS-Daten: {e}")

# DNS Lookup (A-, MX-, NS-Records)
def dns_lookup(domain):
    try:
        a_records = socket.gethostbyname_ex(domain)
        mx_records = socket.getaddrinfo(domain, 0, socket.AF_INET)
        ns_records = socket.gethostbyname_ex(domain)

        print(Fore.GREEN + "\n🔍 DNS-Records:")

        # A-Records
        print(Fore.YELLOW + "\n🌐 A-Records (IP-Adressen der Domain):")
        print(a_records[2])

        # MX-Records (Mail Server)
        print(Fore.YELLOW + "\n📧 MX-Records (Mailserver):")
        for mx in mx_records:
            if 'MX' in mx[0]:
                print(mx)

        # Name Server
        print(Fore.YELLOW + "\n🔗 NS-Records (Name Server):")
        print(ns_records[1])

    except socket.gaierror:
        print(Fore.RED + "❌ Fehler bei DNS-Abfrage")

if __name__ == "__main__":
    display_banner()

    if password_prompt():
        ip_or_domain = input(Fore.GREEN + "🔹 Gib eine IP-Adresse oder Domain ein: ")

        # Prüfen, ob es eine IP-Adresse oder eine Domain ist
        if ip_or_domain.replace('.', '').isdigit():
            ip_lookup(ip_or_domain)
        else:
            print(Fore.GREEN + "\n🌐 Domain gefunden, durchführe WHOIS und DNS Lookup:")
            whois_lookup(ip_or_domain)
            dns_lookup(ip_or_domain)

    input(Fore.GREEN + "\nDrücke Enter zum Beenden...")
