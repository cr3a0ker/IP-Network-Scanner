# IP-Network-Scanner
pip install requests whois tabulate
